  <footer class="mt-auto text-white-50">
    <p>This is a footer lol</p>
  </footer>
</div>
</body>
</html>