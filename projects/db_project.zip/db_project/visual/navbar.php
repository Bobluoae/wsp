  <header class="mb-auto">
    <div>
      <h3 class="mb-0">DB - Intro</h3>
      <nav class="nav nav-masthead justify-content-center">
        <a class="nav-link" aria-current="page" href="?page=table">Show Table</a>
        <a class="nav-link" href="?page=add">Add to Table</a>
        <!-- <a class="nav-link" href="?page=update">Delete from Table</a> -->
      </nav>
    </div>
  </header>