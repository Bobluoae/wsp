<div>
	<form method="POST">
		<input type="hidden" name="addform_skickat">
		<label>Name</label><br>
		<input type="text" name="name" placeholder="Name?" autocomplete="off"><br>
		<label>Surname</label><br>
		<input type="text" name="surname" placeholder="Surname?" autocomplete="off"><br>
		<label>Phonenumber</label><br>
		<input type="number" name="phone" placeholder="Phone number?" autocomplete="off"><br>
		<label>Email</label><br>
		<input type="text" name="email" placeholder="Email?" autocomplete="off"><br>
		<input type="submit" name="Submit"><br>
	</form>
</div>