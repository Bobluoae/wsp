<div>
	<h2>Friends</h1>
	<p>Table displayed from database</p>
</div>